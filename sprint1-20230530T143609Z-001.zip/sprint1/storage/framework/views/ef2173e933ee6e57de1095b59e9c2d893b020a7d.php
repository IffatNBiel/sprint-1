<?php $__env->startSection("content"); ?>
    <main class="flex-grow">
        <div class="pt-4">
            <div class="flex justify-between items-center h-16">
                <form action="/produk" class="flex items-center bg-slate-200 p-1">
                    <label for="keyword" class="material-icons px-2">search</label>
                    <input type="text" name="keyword" id="keyword" class="bg-slate-200 p-0 border-none">
                </form>
                <h1>Daftar Produk</h1>
                <a href="/produk/tambah" class="bg-slate-200 py-1 px-2">Tambah Produk</a>
            </div>
            <div class="flex flex-wrap justify-start overflow-y-scroll max-h-[calc(100vh-6rem)]">
                <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-[20%] p-1">
                        <button data-modal-target="dataProduk" data-modal-toggle="dataProduk"
                                onclick="getDataProduk('<?php echo e($produk->id); ?>', '<?php echo e($produk->nama); ?>', '<?php echo e($produk->gambar); ?>', '<?php echo e($produk->varian->nama); ?>', '<?php echo e($produk->ukuran); ?>', '<?php echo e($produk->harga); ?>', '<?php echo e($produk->deskripsi); ?>')"
                                class="p-2 border w-full flex flex-col gap-2 items-center">
                            <img src="/<?php echo e($produk->gambar); ?>" class="border h-52 w-full object-cover"
                                 alt="<?php echo e($produk->gambar); ?>">
                            <span class="capitalize font-bold text-xl"><?php echo e($produk->nama); ?></span>
                            <span>Rp. <?php echo e($produk->harga); ?></span>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>
    <?php echo $__env->yieldContent("sidebar"); ?>
    <?php echo $__env->make("pages.produk.dataProduk", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="/js/getDataProduk.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minerva/PhpstormProjects/ppl_griees/resources/views/pages/produk/index.blade.php ENDPATH**/ ?>