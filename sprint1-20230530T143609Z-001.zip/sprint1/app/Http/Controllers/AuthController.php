<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function loginform()
    {
        return view("pages.auth.login");
    }

    public function login(Request $request)
    {
        $credential = $request->validate([
            "email" => "required|email|exists:users",
            "password" => "required"
        ]);
        if(Auth::attempt($credential)){
            return redirect()->intended();
        }else{
            return back()->withErrors(["password"=>"Password Wrong"]);
        }
    }
}
