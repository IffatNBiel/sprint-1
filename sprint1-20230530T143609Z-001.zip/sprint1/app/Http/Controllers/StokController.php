<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use Illuminate\Http\Request;

class StokController extends Controller
{
    public function index()
    {
        $produks = Produk::all();
        return view("pages.stok.index", compact("produks"));
    }

    public function tambahStok(Request $request)
    {
        $data = $request->validate([
            "id" => "required",
            "stok" => "required",
            "deskripsi" => "required"
        ]);
        $produk = Produk::find($data["id"]);
        $produk->stok += $data["stok"];
        $produk->save();
        return back();
    }

    public function editStok($id, Request $request){
        $data = $request->validate([
            "stok" => "required",
            "deskripsi" => "required"
        ]);
        $stok = Produk::find($id);
        $stok->stok = $data["stok"];
        $stok->save();
        return back();
    }
}
