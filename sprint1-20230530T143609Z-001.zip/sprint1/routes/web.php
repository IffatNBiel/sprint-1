<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view("index");
});
Route::get("/home", function (){return redirect("/");});

Route::middleware(["guest"])->group(function () {
    Route::get("/login", [\App\Http\Controllers\AuthController::class, "loginform"])->name("login");
    Route::post("/login", [\App\Http\Controllers\AuthController::class, "login"]);
});

Route::middleware(["auth"])->group(function () {
    Route::get('/produk/', [\App\Http\Controllers\ProdukController::class, "index"]);
    Route::get("/pic/produk/{name}", [\App\Http\Controllers\ProdukController::class, "getpic"]);
    Route::get("/produk/p/{id}", [\App\Http\Controllers\ProdukController::class, "getDataProduk"]);
    Route::get("/produk/tambah", [\App\Http\Controllers\ProdukController::class, "tambahProdukForm"]);
    Route::get("/produk/edit/{id}", [\App\Http\Controllers\ProdukController::class, "ubahProdukForm"]);
    Route::post("/produk/tambah", [\App\Http\Controllers\ProdukController::class, "tambahProduk"]);
    Route::post("/produk/edit/{id}", [\App\Http\Controllers\ProdukController::class, "ubahProduk"]);

    Route::get("/stok", [\App\Http\Controllers\StokController::class, "index"]);
    Route::post("/stok/tambah", [\App\Http\Controllers\StokController::class, "tambahStok"]);
    Route::post("/stok/edit/{id}", [\App\Http\Controllers\StokController::class, "editStok"]);

    Route::get("/transaksi", [\App\Http\Controllers\TransaksiController::class, "index"]);
    Route::get("/transaksi/tambah", [\App\Http\Controllers\TransaksiController::class, "tambahForm"]);
    Route::post("/transaksi/tambah", [\App\Http\Controllers\TransaksiController::class, "tambah"]);
});
