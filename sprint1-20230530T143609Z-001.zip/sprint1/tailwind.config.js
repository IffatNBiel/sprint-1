/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
      "./resources/views/**/*.blade.php",
      "./public/js/addTransactionRow.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

