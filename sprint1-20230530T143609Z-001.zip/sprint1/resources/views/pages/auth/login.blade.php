@extends("layouts.main")
@section("content")
<main>
    <form action="/login" method="POST">
        @csrf
        <input type="email" name="email" id="email" placeholder="Email">
        <input type="password" name="password" id="password" placeholder="Password">
        <button type="submit">Login</button>
    </form>
</main>
@stop
